SamSaf Desktop Themes (SamSaf Mario 64 Theme)
---------------------

I applaud anyone who creates themes and distributes them for free. However, 95% of the themes on the Internet are incomplete.
Either they have no or only some cursors, or no sounds, or the wallpaper is of inferior quality.
Some people call themselves theme creators because they have a wallpaper handy and they just create a theme by
throwing together sounds and cursors from other themes.
Sometimes you need to borrow a sound or a cursor from another theme but the whole scheme?

Some themes don't run properly when installed, because the creator strangely assumes that every user will install the
themes in the same directory that he/she used to create them in, e.g.
C:\Windows\Themes\Toons\Work Folder\Nintendo\Mario\Unfinished\Where am I now?

Why be so awkward? If the creator makes the theme look for all its cursors, sounds etc. in the same directory as
itself (THEMEDIR), life would be so easy.

My Desktop Themes are complete. Wallpaper, sounds, cursors, colours etc.
I do not include Start-up etc. screens because WinNT doesn't use them and a lot of Win95 users don't like the small
delay the start-up screens cause. I may include them in the future if the demand is high. Sometimes ScreenSavers are included.
The themes use long filenames, as they are for 32bit Operating Systems this should not be a problem.

Lot of the themes contain wallpaper and sounds that were created by myself.

My themes can be copied onto any drive or directory, all you need to do is:

1. Unzip the file you downloaded with a Zip utility that supports long filenames. This will unzip the theme into your
   default directory in a subfolder with the theme name
 
2. Move the whole subfolder or just the files to your theme folder

3. Create a shortcut to the *.Theme file

I will release themes on a regular basis. My first releases will be Mario themes, although I have made over 100
different subjects. Months of work.


Tip : If you use multiple profiles, you will notice that with any theme all users wallpaper will be the same.
      MS Plus! converts the Wallpaper.jpg to Plus!.bmp and uses Plus!.bmp for all users.
      If you convert your Wallpaper.jpg to Wallpaper.bmp then this will eliminate the problem whereas all users
      will have their own wallpaper.

----------
Disclaimer

Use these themes at your own risk and I will not be liable for anything whatsoever. All copyrights are acknowledged.
All themes are free and no profit is made from them. You may distribute only the complete theme packages.
----------
SamSaf (c) 1998
